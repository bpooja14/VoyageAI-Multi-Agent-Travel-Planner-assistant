import React, { useState, useEffect } from 'react';
import { TripPlan, TripRequest, AgentExecutionLog } from './types';
import { GOA_SAMPLE_PLAN } from './data/sampleTrips';
import { Navbar } from './components/Navbar';
import { PlannerForm } from './components/PlannerForm';
import { AgentGraphVisualizer } from './components/AgentGraphVisualizer';
import { TripResultsView } from './components/TripResultsView';
import { SavedTripsHistory } from './components/SavedTripsHistory';
import { ChatAssistantDrawer } from './components/ChatAssistantDrawer';
import { HumanSupportModal } from './components/HumanSupportModal';
import { Bot, Check, AlertCircle } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'planner' | 'agent-graph' | 'results' | 'history'>('results');
  const [currentPlan, setCurrentPlan] = useState<TripPlan>(GOA_SAMPLE_PLAN);
  const [agentLogs, setAgentLogs] = useState<AgentExecutionLog[]>(GOA_SAMPLE_PLAN.agentLogs);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currency, setCurrency] = useState('₹');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  // Saved trips in LocalStorage
  const [savedTrips, setSavedTrips] = useState<TripPlan[]>(() => {
    try {
      const stored = localStorage.getItem('voyage_ai_saved_trips');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('LocalStorage load failed:', e);
    }
    return [GOA_SAMPLE_PLAN];
  });

  useEffect(() => {
    try {
      localStorage.setItem('voyage_ai_saved_trips', JSON.stringify(savedTrips));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [savedTrips]);

  // Check if current plan is saved
  const isPlanSaved = currentPlan
    ? savedTrips.some((p) => p.id === currentPlan.id)
    : false;

  const handleSaveCurrentPlan = () => {
    if (!currentPlan) return;

    setSavedTrips((prev) => {
      const exists = prev.some((p) => p.id === currentPlan.id);
      if (exists) {
        return prev.map((p) => (p.id === currentPlan.id ? currentPlan : p));
      }
      return [currentPlan, ...prev];
    });

    setSaveSuccessMessage('Trip Plan Saved! You can find it anytime in "My Saved Trips".');
    setTimeout(() => {
      setSaveSuccessMessage(null);
    }, 3500);
  };

  const handlePlanSubmit = async (request: TripRequest) => {
    setIsGenerating(true);
    setErrorMessage(null);
    setActiveTab('agent-graph');

    const initLogs: AgentExecutionLog[] = [
      {
        agent: 'coordinator',
        title: 'Team Leader: Starting New Trip Search',
        status: 'running',
        summary: `Setting up search for ${request.destination} with budget of ${currency} ${request.budget.toLocaleString()}.`,
        details: `Checking requirements for ${request.travelers} people traveling from ${request.originCity}.`,
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
        iteration: 1,
      },
    ];
    setAgentLogs(initLogs);

    try {
      const res = await fetch('/api/plan-trip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...request, currency }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Server failed to coordinate trip');
      }

      const newPlan: TripPlan = await res.json();
      setCurrentPlan(newPlan);
      setAgentLogs(newPlan.agentLogs);

      // Auto-save the freshly coordinated plan
      setSavedTrips((prev) => {
        const exists = prev.some((p) => p.id === newPlan.id);
        if (exists) return prev.map((p) => (p.id === newPlan.id ? newPlan : p));
        return [newPlan, ...prev];
      });

      setTimeout(() => {
        setActiveTab('results');
      }, 700);
    } catch (err: any) {
      console.error('Trip generation error:', err);
      setErrorMessage(err.message || 'Unable to build trip plan. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleLoadGoaBenchmark = () => {
    setCurrentPlan(GOA_SAMPLE_PLAN);
    setAgentLogs(GOA_SAMPLE_PLAN.agentLogs);
    setActiveTab('results');
  };

  const handleUpdatePlan = (updatedPlan: TripPlan) => {
    setCurrentPlan(updatedPlan);
    setSavedTrips((prev) => prev.map((p) => (p.id === updatedPlan.id ? updatedPlan : p)));
  };

  const handleDeleteTrip = (id: string) => {
    setSavedTrips((prev) => prev.filter((p) => p.id !== id));
    if (currentPlan.id === id) {
      const remaining = savedTrips.filter((p) => p.id !== id);
      if (remaining.length > 0) {
        setCurrentPlan(remaining[0]);
      }
    }
  };

  const handleOpenChatWithPrompt = (prompt: string) => {
    setIsChatOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Global Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        hasPlan={!!currentPlan}
        currency={currency}
        setCurrency={setCurrency}
        onNewTrip={() => setActiveTab('planner')}
        onOpenSupport={() => setIsSupportModalOpen(true)}
        onSavePlan={handleSaveCurrentPlan}
        isPlanSaved={isPlanSaved}
        isGenerating={isGenerating}
      />

      {/* Floating Success Save Toast */}
      {saveSuccessMessage && (
        <div className="fixed top-20 right-6 z-50 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="p-3.5 rounded-xl bg-emerald-600 text-white text-xs font-bold shadow-xl flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-200" />
            <span>{saveSuccessMessage}</span>
          </div>
        </div>
      )}

      {/* Error Banner */}
      {errorMessage && (
        <div className="max-w-4xl mx-auto mt-4 px-4">
          <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-rose-600 font-bold hover:underline cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 pb-24">
        {activeTab === 'planner' && (
          <PlannerForm
            onSubmit={handlePlanSubmit}
            isLoading={isGenerating}
            currency={currency}
            onLoadExample={handleLoadGoaBenchmark}
          />
        )}

        {activeTab === 'agent-graph' && (
          <AgentGraphVisualizer
            logs={agentLogs}
            plan={currentPlan}
            isGenerating={isGenerating}
          />
        )}

        {activeTab === 'results' && currentPlan && (
          <TripResultsView
            plan={currentPlan}
            onUpdatePlan={handleUpdatePlan}
            onAskAssistant={handleOpenChatWithPrompt}
            onSavePlan={handleSaveCurrentPlan}
            isPlanSaved={isPlanSaved}
          />
        )}

        {activeTab === 'history' && (
          <SavedTripsHistory
            savedTrips={savedTrips}
            onSelectTrip={(plan) => {
              setCurrentPlan(plan);
              setAgentLogs(plan.agentLogs);
              setActiveTab('results');
            }}
            onDeleteTrip={handleDeleteTrip}
            onLoadBenchmarkGoa={handleLoadGoaBenchmark}
          />
        )}
      </main>

      {/* Floating "Ask AI Travel Assistant" Pill */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setIsChatOpen(true)}
          className="flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-bold text-xs sm:text-sm shadow-xl shadow-indigo-600/30 transition-all cursor-pointer"
          aria-label="Ask AI Travel Assistant"
        >
          <div className="relative">
            <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center text-white">
              <Bot className="w-4 h-4" />
            </div>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 absolute -top-0.5 -right-0.5 border-2 border-indigo-700 animate-pulse" />
          </div>

          <span>Ask AI Travel Assistant</span>

          <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full text-indigo-100 uppercase tracking-wider font-semibold hidden sm:inline-block">
            Clear Doubts
          </span>
        </button>
      </div>

      {/* Slide-over Chat Assistant Drawer */}
      <ChatAssistantDrawer
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        currentPlan={currentPlan}
        onOpenSupport={() => {
          setIsChatOpen(false);
          setIsSupportModalOpen(true);
        }}
      />

      {/* Human Travel Desk Support Modal */}
      <HumanSupportModal
        isOpen={isSupportModalOpen}
        onClose={() => setIsSupportModalOpen(false)}
        tripId={currentPlan?.id}
      />
    </div>
  );
}
