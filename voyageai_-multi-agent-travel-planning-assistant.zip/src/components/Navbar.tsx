import React from 'react';
import { Compass, Bot, FileText, Bookmark, BookmarkCheck, Sparkles, HelpCircle, PlusCircle, Check } from 'lucide-react';

interface NavbarProps {
  activeTab: 'planner' | 'agent-graph' | 'results' | 'history';
  setActiveTab: (tab: 'planner' | 'agent-graph' | 'results' | 'history') => void;
  hasPlan: boolean;
  currency: string;
  setCurrency: (c: string) => void;
  onNewTrip: () => void;
  onOpenSupport: () => void;
  onSavePlan: () => void;
  isPlanSaved: boolean;
  isGenerating?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  hasPlan,
  currency,
  setCurrency,
  onNewTrip,
  onOpenSupport,
  onSavePlan,
  isPlanSaved,
  isGenerating,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => setActiveTab('planner')}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-600 flex items-center justify-center text-white shadow-md">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg text-slate-900 tracking-tight">
                  VoyageAI
                </span>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                  AI Travel Assistant
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block">
                Easy travel planning within your exact budget
              </p>
            </div>
          </div>

          {/* Simple Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setActiveTab('planner')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'planner'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Compass className="w-4 h-4 text-indigo-600" />
              Plan a Trip
            </button>

            <button
              onClick={() => setActiveTab('agent-graph')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-semibold transition-all relative ${
                activeTab === 'agent-graph'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Bot className="w-4 h-4 text-indigo-600" />
              AI Helpers
              {isGenerating && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse absolute -top-0.5 -right-0.5" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('results')}
              disabled={!hasPlan}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                !hasPlan
                  ? 'opacity-40 cursor-not-allowed text-slate-400'
                  : activeTab === 'results'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <FileText className="w-4 h-4 text-indigo-600" />
              Your Trip Plan
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'history'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <BookmarkCheck className="w-4 h-4 text-indigo-600" />
              My Saved Trips
            </button>
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2">
            {/* Quick Save Plan Button in Top Bar */}
            {hasPlan && (
              <button
                type="button"
                onClick={onSavePlan}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg border transition-all ${
                  isPlanSaved
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                    : 'bg-white text-indigo-700 border-indigo-300 hover:bg-indigo-50'
                }`}
                title="Save this trip to view anytime"
              >
                {isPlanSaved ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Saved!</span>
                  </>
                ) : (
                  <>
                    <Bookmark className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Save Trip</span>
                  </>
                )}
              </button>
            )}

            {/* Currency selector */}
            <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200 text-xs font-bold">
              {(['₹', '$', '€'] as const).map((c) => (
                <button
                  key={c}
                  onClick={() => setCurrency(c)}
                  className={`px-2 py-1 rounded-md transition-all ${
                    currency === c ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            {/* Human Concierge Support Button */}
            <button
              onClick={onOpenSupport}
              className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
              title="Need help? Talk to Human Support"
              aria-label="Need help? Talk to Human Support"
            >
              <HelpCircle className="w-5 h-5" />
            </button>

            {/* New Trip CTA */}
            <button
              onClick={onNewTrip}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-all"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              New Trip
            </button>
          </div>
        </div>

        {/* Mobile Tab Row */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-200 text-xs">
          <button
            onClick={() => setActiveTab('planner')}
            className={`flex flex-col items-center gap-1 py-1 px-2 font-medium ${
              activeTab === 'planner' ? 'text-indigo-600 font-bold' : 'text-slate-500'
            }`}
          >
            <Compass className="w-4 h-4" />
            Plan Trip
          </button>
          <button
            onClick={() => setActiveTab('agent-graph')}
            className={`flex flex-col items-center gap-1 py-1 px-2 font-medium ${
              activeTab === 'agent-graph' ? 'text-indigo-600 font-bold' : 'text-slate-500'
            }`}
          >
            <Bot className="w-4 h-4" />
            AI Helpers
          </button>
          <button
            onClick={() => setActiveTab('results')}
            disabled={!hasPlan}
            className={`flex flex-col items-center gap-1 py-1 px-2 font-medium ${
              !hasPlan ? 'opacity-30' : activeTab === 'results' ? 'text-indigo-600 font-bold' : 'text-slate-500'
            }`}
          >
            <FileText className="w-4 h-4" />
            Your Plan
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex flex-col items-center gap-1 py-1 px-2 font-medium ${
              activeTab === 'history' ? 'text-indigo-600 font-bold' : 'text-slate-500'
            }`}
          >
            <BookmarkCheck className="w-4 h-4" />
            Saved
          </button>
        </div>
      </div>
    </header>
  );
};
