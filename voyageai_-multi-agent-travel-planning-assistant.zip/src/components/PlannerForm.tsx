import React, { useState } from 'react';
import { TripRequest } from '../types';
import {
  MapPin,
  Calendar,
  Users,
  Wallet,
  Sparkles,
  Plane,
  Building,
  Heart,
  ShieldCheck,
  ArrowRight,
  Clock,
  Compass,
} from 'lucide-react';

interface PlannerFormProps {
  onSubmit: (request: TripRequest) => void;
  isLoading: boolean;
  currency: string;
  onLoadExample: () => void;
}

const DESTINATION_OPTIONS = [
  { value: 'Goa, India', label: '🏖️ Goa (Beaches, Sea Food & Sunsets)' },
  { value: 'Manali, Himachal Pradesh', label: '🏔️ Manali (Snow Mountains, Hills & Nature)' },
  { value: 'Jaipur, Rajasthan', label: '🏰 Jaipur (Palaces, Forts & Royal Culture)' },
  { value: 'Munnar & Alleppey, Kerala', label: '🌴 Kerala (Tea Gardens & Backwaters)' },
  { value: 'Udaipur, Rajasthan', label: '⛵ Udaipur (Lakes, Havelis & Heritage)' },
  { value: 'Agra, Uttar Pradesh', label: '🕌 Agra (Taj Mahal & Mughal History)' },
  { value: 'Shimla, Himachal Pradesh', label: '🌲 Shimla (Mall Road & Pine Valleys)' },
  { value: 'Ooty, Tamil Nadu', label: '☕ Ooty (Tea Hills & Toy Train)' },
  { value: 'Andaman Islands', label: '🌊 Andaman (Blue Lagoons & White Beaches)' },
  { value: 'custom', label: '✏️ Type Other Destination...' },
];

const ORIGIN_CITY_OPTIONS = [
  'Mumbai',
  'Delhi',
  'Bengaluru',
  'Pune',
  'Ahmedabad',
  'Hyderabad',
  'Chennai',
  'Kolkata',
  'Jaipur',
  'Surat',
  'custom',
];

const BUDGET_PRESET_OPTIONS = [
  { value: 15000, label: '₹ 15,000 (Solo / Budget friendly)' },
  { value: 25000, label: '₹ 25,000 (Goa 3-Day Trip for 2 People)' },
  { value: 35000, label: '₹ 35,000 (Comfortable 3-4 Day Trip)' },
  { value: 50000, label: '₹ 50,000 (Relaxed Holiday with Good Hotels)' },
  { value: 75000, label: '₹ 75,000 (Luxury Stay & Fine Dining)' },
  { value: 0, label: '✏️ Choose Custom Amount' },
];

const DURATION_PRESETS = [
  { days: 3, label: '3 Days / 2 Nights (Weekend Trip)' },
  { days: 4, label: '4 Days / 3 Nights' },
  { days: 5, label: '5 Days / 4 Nights' },
  { days: 7, label: '7 Days / 6 Nights (Full Week)' },
];

const INTEREST_OPTIONS = [
  'Beaches & Sea',
  'Famous Sightseeing',
  'Local Food & Cafes',
  'Water Sports',
  'Forts & History',
  'Nature & Greenery',
  'Market Shopping',
  'Evening Nightlife',
  'Relaxation & Spa',
];

export const PlannerForm: React.FC<PlannerFormProps> = ({
  onSubmit,
  isLoading,
  currency,
  onLoadExample,
}) => {
  // Dropdown states
  const [selectedDestOption, setSelectedDestOption] = useState('Goa, India');
  const [customDestination, setCustomDestination] = useState('');

  const [selectedOriginOption, setSelectedOriginOption] = useState('Mumbai');
  const [customOrigin, setCustomOrigin] = useState('');

  const [durationDays, setDurationDays] = useState(3);
  const [startDate, setStartDate] = useState('2026-11-12');
  const [travelers, setTravelers] = useState(2);

  const [selectedBudgetPreset, setSelectedBudgetPreset] = useState(25000);
  const [customBudget, setCustomBudget] = useState(25000);

  const [travelStyle, setTravelStyle] = useState<TripRequest['travelStyle']>('Balanced');
  const [accommodationType, setAccommodationType] = useState('3-Star Resort with Pool');
  const [interests, setInterests] = useState<string[]>([
    'Beaches & Sea',
    'Local Food & Cafes',
    'Forts & History',
    'Water Sports',
  ]);

  const toggleInterest = (interest: string) => {
    if (interests.includes(interest)) {
      setInterests(interests.filter((i) => i !== interest));
    } else {
      setInterests([...interests, interest]);
    }
  };

  // Calculate actual destination & origin
  const finalDestination =
    selectedDestOption === 'custom'
      ? customDestination.trim() || 'Goa, India'
      : selectedDestOption;

  const finalOrigin =
    selectedOriginOption === 'custom'
      ? customOrigin.trim() || 'Mumbai'
      : selectedOriginOption;

  const finalBudget =
    selectedBudgetPreset === 0 ? customBudget : selectedBudgetPreset;

  // Calculate end date based on duration days
  const calculateEndDate = () => {
    const start = new Date(startDate);
    start.setDate(start.getDate() + durationDays);
    return start.toISOString().split('T')[0];
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const endDate = calculateEndDate();

    onSubmit({
      destination: finalDestination,
      originCity: finalOrigin,
      startDate,
      endDate,
      travelers,
      budget: finalBudget,
      currency,
      interests,
      travelStyle,
      accommodationType,
    });
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      {/* Friendly Hero Banner with 1-Click Goa Benchmark */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-900 via-blue-900 to-slate-900 p-6 sm:p-8 text-white shadow-lg mb-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="max-w-xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-indigo-200 border border-white/20 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" /> Easy Travel Planning
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Plan Your Complete Trip in Seconds
            </h1>
            <p className="mt-2 text-indigo-100/90 text-sm leading-relaxed">
              Our 4 smart AI helpers search flights, pick clean hotels, plan fun daily activities, and make sure everything stays within your exact budget!
            </p>
          </div>

          {/* Quick Benchmark Button */}
          <div className="w-full md:w-auto shrink-0 bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
            <div className="text-xs font-bold text-amber-300 uppercase tracking-wider mb-1">
              Sample Trip Idea
            </div>
            <p className="text-xs text-white font-semibold mb-3">
              3-Day Goa Trip for 2 People (₹25,000 Budget)
            </p>
            <button
              type="button"
              onClick={onLoadExample}
              className="w-full py-2.5 px-4 text-xs font-bold rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              See This Plan Now <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Form with Dropdown Select Options */}
      <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
        <div className="pb-5 border-b border-slate-100 mb-6">
          <h2 className="text-lg font-bold text-slate-900">Enter Your Trip Details</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Simply pick from the options below, then click the blue button to build your trip plan.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* 1. Destination Select Dropdown */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-rose-500" /> 1. Where do you want to go?
              </span>
            </label>
            <select
              value={selectedDestOption}
              onChange={(e) => setSelectedDestOption(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-800 bg-white focus:border-indigo-500 focus:outline-none cursor-pointer"
            >
              {DESTINATION_OPTIONS.map((dest) => (
                <option key={dest.value} value={dest.value}>
                  {dest.label}
                </option>
              ))}
            </select>

            {selectedDestOption === 'custom' && (
              <input
                type="text"
                required
                value={customDestination}
                onChange={(e) => setCustomDestination(e.target.value)}
                placeholder="Type your destination city name..."
                className="mt-2 w-full px-3.5 py-2 text-sm rounded-xl border border-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-100"
              />
            )}
          </div>

          {/* 2. Origin City Select Dropdown */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5">
                <Plane className="w-4 h-4 text-blue-500" /> 2. Where are you starting from?
              </span>
            </label>
            <select
              value={selectedOriginOption}
              onChange={(e) => setSelectedOriginOption(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-800 bg-white focus:border-indigo-500 focus:outline-none cursor-pointer"
            >
              {ORIGIN_CITY_OPTIONS.map((city) => (
                <option key={city} value={city}>
                  {city === 'custom' ? '✏️ Type Other City...' : `${city} (Airport / Station)`}
                </option>
              ))}
            </select>

            {selectedOriginOption === 'custom' && (
              <input
                type="text"
                required
                value={customOrigin}
                onChange={(e) => setCustomOrigin(e.target.value)}
                placeholder="Type your departure city..."
                className="mt-2 w-full px-3.5 py-2 text-sm rounded-xl border border-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-100"
              />
            )}
          </div>
        </div>

        {/* 3. Number of People and Trip Length */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-6">
          {/* Number of People */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-indigo-500" /> 3. How many people?
              </span>
            </label>
            <select
              value={travelers}
              onChange={(e) => setTravelers(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-800 bg-white focus:border-indigo-500 focus:outline-none cursor-pointer"
            >
              <option value={1}>1 Person (Solo Travel)</option>
              <option value={2}>2 People (Couple / Friends)</option>
              <option value={3}>3 People</option>
              <option value={4}>4 People (Small Family / Group)</option>
              <option value={5}>5 People</option>
              <option value={6}>6+ People (Group)</option>
            </select>
          </div>

          {/* Trip Duration Select */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-emerald-500" /> 4. Trip Duration
              </span>
            </label>
            <select
              value={durationDays}
              onChange={(e) => setDurationDays(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-800 bg-white focus:border-indigo-500 focus:outline-none cursor-pointer"
            >
              {DURATION_PRESETS.map((dur) => (
                <option key={dur.days} value={dur.days}>
                  {dur.label}
                </option>
              ))}
            </select>
          </div>

          {/* Start Date */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-purple-500" /> 5. Starting Date
              </span>
            </label>
            <input
              type="date"
              required
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-800 bg-white focus:border-indigo-500 focus:outline-none"
            />
          </div>
        </div>

        {/* 4. Budget Select Options */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 mb-6">
          <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
            <span className="flex items-center gap-1.5">
              <Wallet className="w-4 h-4 text-amber-500" /> 6. What is your total budget for everyone?
            </span>
          </label>
          <p className="text-xs text-slate-500 mb-3">
            Our AI will calculate flights, hotel, food, local transport, and activities to fit inside this exact amount.
          </p>

          <select
            value={selectedBudgetPreset}
            onChange={(e) => {
              const val = Number(e.target.value);
              setSelectedBudgetPreset(val);
              if (val > 0) setCustomBudget(val);
            }}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-bold text-slate-900 bg-white focus:border-indigo-500 focus:outline-none cursor-pointer"
          >
            {BUDGET_PRESET_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>

          {selectedBudgetPreset === 0 && (
            <div className="mt-3 flex items-center gap-2">
              <span className="text-sm font-bold text-slate-700">{currency}</span>
              <input
                type="number"
                min={5000}
                max={500000}
                step={1000}
                value={customBudget}
                onChange={(e) => setCustomBudget(Number(e.target.value))}
                placeholder="Enter custom budget amount"
                className="flex-1 px-3 py-2 text-sm font-bold rounded-xl border border-indigo-300 focus:outline-none"
              />
            </div>
          )}

          <div className="mt-2 text-right text-xs font-semibold text-indigo-700">
            Selected Budget: {currency} {finalBudget.toLocaleString()} (approx {currency} {Math.round(finalBudget / Math.max(1, travelers)).toLocaleString()} per person)
          </div>
        </div>

        {/* 5. Travel Style and Hotel Type Dropdowns */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* Travel Style */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              7. Travel Style
            </label>
            <select
              value={travelStyle}
              onChange={(e) => setTravelStyle(e.target.value as any)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-800 bg-white focus:border-indigo-500 focus:outline-none cursor-pointer"
            >
              <option value="Balanced">Balanced (Best mix of comfort & reasonable price)</option>
              <option value="Budget">Budget Friendly (Save money, practical stays)</option>
              <option value="Luxury">Luxury (Premium hotels & top dining)</option>
              <option value="Adventure">Adventure (Outdoor sports, treks & explore)</option>
              <option value="Relaxed">Relaxed (Slow pace, scenic viewpoints & chill)</option>
            </select>
          </div>

          {/* Hotel Preference */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5">
                <Building className="w-4 h-4 text-purple-500" /> 8. Where would you like to stay?
              </span>
            </label>
            <select
              value={accommodationType}
              onChange={(e) => setAccommodationType(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-800 bg-white focus:border-indigo-500 focus:outline-none cursor-pointer"
            >
              <option value="3-Star Resort with Pool">3-Star Resort with Pool (Recommended)</option>
              <option value="Boutique Hotel near Beach">Boutique Hotel near Main Attractions</option>
              <option value="Budget Friendly Hotel / Hostel">Budget Friendly Hotel / Clean Guesthouse</option>
              <option value="Luxury 5-Star Beachfront Resort">Luxury 5-Star Beachfront Resort</option>
            </select>
          </div>
        </div>

        {/* 6. What do you like to do? (Interests) */}
        <div className="mb-8">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
            <span className="flex items-center gap-1.5">
              <Heart className="w-4 h-4 text-rose-500" /> 9. What activities do you like? (Tap to select)
            </span>
          </label>
          <div className="flex flex-wrap gap-2">
            {INTEREST_OPTIONS.map((item) => {
              const active = interests.includes(item);
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => toggleInterest(item)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                    active
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {item} {active && '✓'}
                </button>
              );
            })}
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              100% Free & Safe: You review everything first. No automatic booking or charges.
            </span>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Planning Your Trip...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                Build My Trip Plan Now
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
