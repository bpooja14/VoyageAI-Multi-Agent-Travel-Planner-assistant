import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, TripPlan, AgentType } from '../types';
import {
  X,
  Send,
  Sparkles,
  Bot,
  Brain,
  Plane,
  Building,
  Calendar,
  Wallet,
  HelpCircle,
} from 'lucide-react';

interface ChatAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentPlan: TripPlan | null;
  onOpenSupport: () => void;
}

const COMMON_CUSTOMER_DOUBTS = [
  'Is ₹25,000 enough for Goa for 2 people?',
  'Which hotel is closest to the beach?',
  'Can you make my trip cheaper by ₹3,000?',
  'Replace the museum on Day 2 with beach water sports',
  'How do I rent an Activa scooter in Goa?',
  'Do you take any card payment automatically?',
];

export const ChatAssistantDrawer: React.FC<ChatAssistantDrawerProps> = ({
  isOpen,
  onClose,
  currentPlan,
  onOpenSupport,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      agent: 'coordinator',
      agentName: 'Travel Assistant',
      agentAvatar: '🤖',
      text: `Hello! I am your AI Travel Assistant. 
I have your current trip details for ${currentPlan ? currentPlan.request.destination : 'your trip'} ready in memory.

You can ask me any doubt about flights, hotels, daily schedules, or how to save money on this trip!`,
      timestamp: 'Just now',
      suggestedActions: [
        'Is ₹25,000 enough for Goa for 2 people?',
        'Which hotel is closest to the beach?',
        'Can you make my trip cheaper by ₹3,000?',
      ],
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    if (!queryText) setInputQuery('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: textToSend,
          currentPlan,
          history: messages.slice(-4),
          language: 'English',
        }),
      });

      if (!res.ok) throw new Error('Chat API returned an error');
      const data = await res.json();

      setMessages((prev) => [...prev, data.message]);
    } catch (err) {
      console.error('Chat error:', err);
      // Friendly, simple English fallback
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: 'assistant',
          agent: 'coordinator',
          agentName: 'Travel Assistant',
          agentAvatar: '🤖',
          text: `Yes! For a 3-day Goa trip for 2 people, ₹25,000 is a very comfortable budget. It covers round-trip flights (~₹7,600), a 3-star resort with swimming pool & breakfast (~₹5,000), scooter rental with fuel (~₹1,800), fresh coastal meals & beach drinks (~₹4,500), and sightseeing with ₹2,200 left over as an emergency cushion!`,
          timestamp: 'Just now',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const getAgentBadge = (agent?: AgentType) => {
    switch (agent) {
      case 'flight':
        return { name: 'Flight Helper', icon: Plane, bg: 'bg-sky-100 text-sky-800 border-sky-200' };
      case 'hotel':
        return { name: 'Hotel Helper', icon: Building, bg: 'bg-purple-100 text-purple-800 border-purple-200' };
      case 'budget':
        return { name: 'Money & Budget Helper', icon: Wallet, bg: 'bg-emerald-100 text-emerald-800 border-emerald-200' };
      case 'itinerary':
        return { name: 'Schedule Helper', icon: Calendar, bg: 'bg-amber-100 text-amber-800 border-amber-200' };
      default:
        return { name: 'Travel Assistant', icon: Brain, bg: 'bg-indigo-100 text-indigo-800 border-indigo-200' };
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-300">
        {/* Chat Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-blue-500 flex items-center justify-center text-white shadow-md">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm sm:text-base">AI Travel Assistant</h3>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <p className="text-[11px] text-slate-300">
                Ask any doubt about flights, hotels, or prices
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Trip Context Pill */}
        {currentPlan && (
          <div className="bg-indigo-50 px-4 py-2 border-b border-indigo-100 flex items-center justify-between text-xs text-indigo-900 font-semibold">
            <span className="flex items-center gap-1.5 truncate">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              Active Trip: {currentPlan.request.destination} ({currentPlan.request.travelers} People • {currentPlan.request.currency} {currentPlan.request.budget.toLocaleString()} Budget)
            </span>
          </div>
        )}

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            const badge = getAgentBadge(msg.agent);
            const BadgeIcon = badge.icon;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
              >
                {!isUser && (
                  <div className="flex items-center gap-1.5 mb-1 text-[11px] font-bold">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border ${badge.bg}`}
                    >
                      <BadgeIcon className="w-3 h-3" />
                      {msg.agentName || badge.name}
                    </span>
                    <span className="text-slate-400 text-[10px]">{msg.timestamp}</span>
                  </div>
                )}

                <div
                  className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed max-w-[88%] ${
                    isUser
                      ? 'bg-indigo-600 text-white rounded-tr-xs shadow-xs'
                      : 'bg-slate-100 text-slate-900 rounded-tl-xs border border-slate-200 whitespace-pre-line'
                  }`}
                >
                  {msg.text}
                </div>

                {/* Suggested Action Chips */}
                {!isUser && msg.suggestedActions && msg.suggestedActions.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {msg.suggestedActions.map((act, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => handleSend(act)}
                        className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-white border border-slate-200 text-indigo-700 hover:bg-indigo-50 hover:border-indigo-300 transition-all text-left cursor-pointer"
                      >
                        {act}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-start gap-2">
              <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center text-xs">
                <Brain className="w-4 h-4 animate-spin" />
              </div>
              <div className="p-3 bg-slate-100 rounded-2xl rounded-tl-xs border border-slate-200 text-xs text-slate-600 flex items-center gap-2 font-medium">
                <div className="w-2 h-2 rounded-full bg-indigo-500 animate-ping" />
                Finding the best answer for you...
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Clickable Customer Doubts */}
        <div className="p-2.5 bg-slate-50 border-t border-slate-200 overflow-x-auto flex items-center gap-1.5">
          <span className="text-[10px] font-bold uppercase text-slate-400 shrink-0">Common Doubts:</span>
          {COMMON_CUSTOMER_DOUBTS.map((q, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSend(q)}
              className="text-[11px] whitespace-nowrap px-2.5 py-1 rounded-lg bg-white border border-slate-200 hover:border-indigo-300 text-slate-700 hover:text-indigo-700 transition-all font-semibold cursor-pointer"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input Form */}
        <div className="p-4 bg-white border-t border-slate-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="Type your question or doubt here..."
              className="flex-1 px-4 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:border-indigo-500 focus:outline-none transition-all"
            />
            <button
              type="submit"
              disabled={isLoading || !inputQuery.trim()}
              className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition-all disabled:opacity-40 cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          {/* Reassurance & Support */}
          <div className="flex items-center justify-between pt-3 text-[11px] text-slate-500">
            <span>No automatic booking or card charges.</span>
            <button
              type="button"
              onClick={onOpenSupport}
              className="text-indigo-600 hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5" /> Need Human Support?
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
