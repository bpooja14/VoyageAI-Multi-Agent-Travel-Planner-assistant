import React from 'react';
import { AgentExecutionLog, TripPlan } from '../types';
import {
  Brain,
  Plane,
  Building,
  Calendar,
  Wallet,
  CheckCircle2,
  RefreshCw,
  Clock,
  Sparkles,
  Users,
} from 'lucide-react';

interface AgentGraphVisualizerProps {
  logs: AgentExecutionLog[];
  plan: TripPlan | null;
  isGenerating?: boolean;
}

export const AgentGraphVisualizer: React.FC<AgentGraphVisualizerProps> = ({
  logs,
  plan,
  isGenerating,
}) => {
  const helpers = [
    {
      id: 'coordinator',
      simpleName: '1. Team Leader',
      techName: 'Coordinator Agent',
      role: 'Guides the entire plan',
      icon: Brain,
      bgColor: 'bg-indigo-50 border-indigo-200 text-indigo-700',
      activeRing: 'ring-indigo-500',
      simpleDescription: 'Reads your destination, dates, and budget, then gives tasks to the other 4 helpers.',
    },
    {
      id: 'flight',
      simpleName: '2. Flight Finder',
      techName: 'Flight Agent',
      role: 'Searches tickets',
      icon: Plane,
      bgColor: 'bg-sky-50 border-sky-200 text-sky-700',
      activeRing: 'ring-sky-500',
      simpleDescription: 'Checks departure times, luggage rules, and finds the best value round-trip flights.',
    },
    {
      id: 'hotel',
      simpleName: '3. Hotel Finder',
      techName: 'Hotel Agent',
      role: 'Finds clean stays',
      icon: Building,
      bgColor: 'bg-purple-50 border-purple-200 text-purple-700',
      activeRing: 'ring-purple-500',
      simpleDescription: 'Looks for top-rated resorts and hotels with pools, free breakfast, and good locations.',
    },
    {
      id: 'itinerary',
      simpleName: '4. Schedule Planner',
      techName: 'Itinerary Agent',
      role: 'Plans daily activities',
      icon: Calendar,
      bgColor: 'bg-amber-50 border-amber-200 text-amber-700',
      activeRing: 'ring-amber-500',
      simpleDescription: 'Arranges morning, afternoon, and evening sights, beach visits, and local food stops.',
    },
    {
      id: 'budget',
      simpleName: '5. Money Manager',
      techName: 'Budget Agent',
      role: 'Guarantees your budget',
      icon: Wallet,
      bgColor: 'bg-emerald-50 border-emerald-200 text-emerald-700',
      activeRing: 'ring-emerald-500',
      simpleDescription: 'Calculates every rupee. If total exceeds your budget, it immediately finds cheaper alternatives!',
    },
  ];

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-xs font-bold text-indigo-700 mb-2">
              <Users className="w-3.5 h-3.5 text-indigo-600" /> Coordinated AI Team
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              How Your 5 AI Helpers Work Together
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Instead of just one basic chatbot, five specialized assistants coordinate in real time to build a realistic, budget-friendly trip.
            </p>
          </div>

          {plan && (
            <div className="flex items-center gap-3 bg-emerald-50 border border-emerald-200 rounded-xl p-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900">
                  Budget Verification
                </div>
                <div className="text-xs text-emerald-700 font-bold">
                  ✓ Successfully Checked within Budget
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 5 Helper Cards */}
        <div className="mt-8 pt-8 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {helpers.map((helper) => {
            const Icon = helper.icon;
            const hasRan = logs.some((l) => l.agent === helper.id);
            const isCurrentlyRunning = isGenerating && logs[logs.length - 1]?.agent === helper.id;

            return (
              <div
                key={helper.id}
                className={`rounded-2xl border p-4 transition-all flex flex-col justify-between ${
                  helper.bgColor
                } ${isCurrentlyRunning ? `ring-2 ${helper.activeRing} shadow-md` : 'shadow-2xs'}`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-white shadow-xs flex items-center justify-center text-current">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-white text-slate-700 border border-current/10">
                      Step
                    </span>
                  </div>

                  <h3 className="font-extrabold text-sm text-slate-900">{helper.simpleName}</h3>
                  <div className="text-[11px] font-bold text-slate-600 mt-0.5">{helper.role}</div>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                    {helper.simpleDescription}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-current/10 flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-500">Status:</span>
                  <span className="font-bold">
                    {isCurrentlyRunning ? (
                      <span className="text-amber-600 flex items-center gap-1">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Working...
                      </span>
                    ) : hasRan ? (
                      <span className="text-emerald-700 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Ready ✓
                      </span>
                    ) : (
                      <span className="text-slate-400">Waiting</span>
                    )}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Automatic Budget Protection Banner */}
        <div className="mt-6 p-4 rounded-xl bg-gradient-to-r from-amber-50 to-indigo-50 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start gap-2.5">
            <div className="p-1.5 rounded-lg bg-amber-100 text-amber-800 shrink-0 mt-0.5">
              <RefreshCw className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-slate-900 block">
                Automatic Budget Protection
              </span>
              <span className="text-slate-600">
                If the hotel and flight costs initially exceed your budget, the Team Leader automatically instructs the helpers to find cheaper flights and boutique hotels until your plan is comfortably under budget.
              </span>
            </div>
          </div>
          <div className="shrink-0 font-bold text-emerald-700 bg-white px-3 py-1.5 rounded-lg border border-emerald-200">
            ✓ Keeps You Safe from Overspending
          </div>
        </div>
      </div>

      {/* Step-by-Step History Log */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                Step-by-Step Progress History
              </h3>
              <p className="text-xs text-slate-500">
                Shows exactly what each helper searched and confirmed for your trip.
              </p>
            </div>
          </div>
        </div>

        <div className="divide-y divide-slate-100 max-h-[450px] overflow-y-auto">
          {logs.map((log, index) => (
            <div key={index} className="p-4 sm:p-5 hover:bg-slate-50 transition-colors">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-sm shrink-0 mt-0.5">
                    {log.agent === 'coordinator' && '🧠'}
                    {log.agent === 'flight' && '✈️'}
                    {log.agent === 'hotel' && '🏨'}
                    {log.agent === 'itinerary' && '📅'}
                    {log.agent === 'budget' && '💰'}
                  </div>

                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{log.title}</h4>
                    <p className="text-xs text-slate-700 mt-1">{log.summary}</p>
                    <p className="text-xs text-slate-500 mt-1.5 bg-slate-50 p-2 rounded-lg border border-slate-100 font-medium">
                      {log.details}
                    </p>
                  </div>
                </div>

                <div className="shrink-0 flex flex-col items-end gap-1">
                  <span className="text-[11px] font-mono text-slate-400">{log.timestamp}</span>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    Done ✓
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
