import React, { useState } from 'react';
import { FlightOption, HotelOption, TripPlan } from '../types';
import {
  MapPin,
  Calendar,
  Users,
  Wallet,
  Plane,
  Building,
  CheckCircle2,
  ExternalLink,
  Clock,
  Sparkles,
  ShieldCheck,
  Bookmark,
  Printer,
  Share2,
  ArrowRight,
  Utensils,
  Car,
  Ticket,
  Check,
  MessageSquare,
} from 'lucide-react';

interface TripResultsViewProps {
  plan: TripPlan;
  onUpdatePlan: (updatedPlan: TripPlan) => void;
  onAskAssistant: (prompt: string) => void;
  onSavePlan: () => void;
  isPlanSaved: boolean;
}

export const TripResultsView: React.FC<TripResultsViewProps> = ({
  plan,
  onUpdatePlan,
  onAskAssistant,
  onSavePlan,
  isPlanSaved,
}) => {
  const [activeTab, setActiveTab] = useState<'itinerary' | 'flights' | 'hotels' | 'budget' | 'booking'>('itinerary');
  const [selectedDayIndex, setSelectedDayIndex] = useState(0);
  const [approvedChecked, setApprovedChecked] = useState(plan.approvedByCustomer);
  const [copiedNotification, setCopiedNotification] = useState(false);

  const { request, summary, flights, hotels, itinerary, budget, validationStatus } = plan;
  const currency = request.currency || '₹';

  // Handle switching flight alternative
  const handleSelectFlight = (flight: FlightOption) => {
    const updatedAlternatives = [
      flights.selectedFlight,
      ...flights.alternatives.filter((f) => f.id !== flight.id),
    ];

    const diff = flight.totalPrice - flights.selectedFlight.totalPrice;
    const newCalculatedTotal = budget.calculatedTotal + diff;
    const newBalance = budget.targetBudget - newCalculatedTotal;

    const updatedPlan: TripPlan = {
      ...plan,
      flights: {
        ...flights,
        selectedFlight: { ...flight, selected: true },
        alternatives: updatedAlternatives.map((f) => ({ ...f, selected: false })),
      },
      budget: {
        ...budget,
        calculatedTotal: newCalculatedTotal,
        balance: newBalance,
        isWithinBudget: newBalance >= 0,
        savingsOrOverrun: Math.abs(newBalance),
        categories: budget.categories.map((cat) => {
          if (cat.category.includes('Flight')) {
            return {
              ...cat,
              amount: flight.totalPrice,
              percentage: Math.round((flight.totalPrice / newCalculatedTotal) * 100),
              details: `${flight.airline} round-trip for ${request.travelers} travelers`,
            };
          }
          return {
            ...cat,
            percentage: Math.round((cat.amount / newCalculatedTotal) * 100),
          };
        }),
      },
    };
    onUpdatePlan(updatedPlan);
  };

  // Handle switching hotel alternative
  const handleSelectHotel = (hotel: HotelOption) => {
    const updatedAlternatives = [
      hotels.selectedHotel,
      ...hotels.alternatives.filter((h) => h.id !== hotel.id),
    ];

    const diff = hotel.totalPrice - hotels.selectedHotel.totalPrice;
    const newCalculatedTotal = budget.calculatedTotal + diff;
    const newBalance = budget.targetBudget - newCalculatedTotal;

    const updatedPlan: TripPlan = {
      ...plan,
      hotels: {
        ...hotels,
        selectedHotel: { ...hotel, selected: true },
        alternatives: updatedAlternatives.map((h) => ({ ...h, selected: false })),
      },
      budget: {
        ...budget,
        calculatedTotal: newCalculatedTotal,
        balance: newBalance,
        isWithinBudget: newBalance >= 0,
        savingsOrOverrun: Math.abs(newBalance),
        categories: budget.categories.map((cat) => {
          if (cat.category.includes('Hotel')) {
            return {
              ...cat,
              amount: hotel.totalPrice,
              percentage: Math.round((hotel.totalPrice / newCalculatedTotal) * 100),
              details: `${hotel.name} (${hotel.totalNights} nights, ${hotel.roomType})`,
            };
          }
          return {
            ...cat,
            percentage: Math.round((cat.amount / newCalculatedTotal) * 100),
          };
        }),
      },
    };
    onUpdatePlan(updatedPlan);
  };

  const handleApprovePlan = () => {
    setApprovedChecked(true);
    onUpdatePlan({
      ...plan,
      approvedByCustomer: true,
    });
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedNotification(true);
      setTimeout(() => setCopiedNotification(false), 2500);
    }
  };

  const currentDay = itinerary[selectedDayIndex] || itinerary[0];

  return (
    <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6 space-y-6">
      {/* Top Banner: Trip Overview & Obvious Save Button */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                <CheckCircle2 className="w-3.5 h-3.5" /> Checked & Within Your Budget
              </span>

              {plan.approvedByCustomer && (
                <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30">
                  <ShieldCheck className="w-3.5 h-3.5" /> Approved by You
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {summary.title}
            </h1>
            <p className="text-sm text-indigo-100/90 leading-relaxed">
              {summary.description}
            </p>

            {/* Simple Highlights */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {summary.destinationHighlights.map((hl, idx) => (
                <span
                  key={idx}
                  className="text-xs font-medium px-2.5 py-1 rounded-md bg-white/10 text-white/90 border border-white/10"
                >
                  ✓ {hl}
                </span>
              ))}
            </div>
          </div>

          {/* Quick Summary Card with Big Save Button */}
          <div className="shrink-0 bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/20 space-y-3 min-w-[280px]">
            <div className="flex items-center justify-between">
              <span className="text-xs text-indigo-200 font-semibold">Total Estimated Cost:</span>
              <span className="text-2xl font-extrabold text-white">
                {currency} {budget.calculatedTotal.toLocaleString()}
              </span>
            </div>

            {/* Budget status */}
            <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-xs text-emerald-200 flex items-center justify-between font-bold">
              <span>Your Budget: {currency} {budget.targetBudget.toLocaleString()}</span>
              <span>
                {budget.isWithinBudget
                  ? `✓ Saved ${currency} ${budget.balance.toLocaleString()}`
                  : `⚠️ ${currency} ${budget.savingsOrOverrun.toLocaleString()} over`}
              </span>
            </div>

            {/* PROMINENT SAVE TRIP BUTTON */}
            <button
              type="button"
              onClick={onSavePlan}
              className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
                isPlanSaved
                  ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                  : 'bg-amber-400 hover:bg-amber-300 text-slate-950'
              }`}
            >
              {isPlanSaved ? (
                <>
                  <Check className="w-4 h-4" />
                  Trip Saved in 'My Saved Trips'!
                </>
              ) : (
                <>
                  <Bookmark className="w-4 h-4" />
                  Save This Trip Plan
                </>
              )}
            </button>

            {/* Share and Print buttons */}
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={handleShare}
                className="flex-1 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-all flex items-center justify-center gap-1 cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5" />
                {copiedNotification ? 'Link Copied!' : 'Share'}
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="flex-1 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-all flex items-center justify-center gap-1 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" /> Print
              </button>
            </div>
          </div>
        </div>

        {/* Quick parameters info */}
        <div className="mt-6 pt-5 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs text-slate-300">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Dates</span>
            <span className="font-semibold text-white">{request.startDate} to {request.endDate}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Travelers</span>
            <span className="font-semibold text-white">{request.travelers} Persons ({request.travelStyle})</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Weather</span>
            <span className="font-semibold text-white">{summary.weatherForecast.split(',')[0]}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Where to Stay</span>
            <span className="font-semibold text-white">{hotels.selectedHotel.name.slice(0, 24)}</span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs in Simple Everyday English */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-1">
        {[
          { id: 'itinerary', label: '1. Daily Schedule', icon: Calendar },
          { id: 'flights', label: '2. Flights', icon: Plane },
          { id: 'hotels', label: '3. Hotel', icon: Building },
          { id: 'budget', label: '4. Cost Breakdown', icon: Wallet },
          { id: 'booking', label: '5. How to Book (Checklist)', icon: ShieldCheck },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'border-indigo-600 text-indigo-700 bg-indigo-50/70 rounded-t-xl'
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* TAB 1: DAILY SCHEDULE */}
      {activeTab === 'itinerary' && (
        <div className="space-y-6">
          {/* Day Selector Buttons */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {itinerary.map((day, idx) => (
              <button
                key={day.dayNumber}
                onClick={() => setSelectedDayIndex(idx)}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 cursor-pointer ${
                  selectedDayIndex === idx
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                <span>Day {day.dayNumber}</span>
                <span className={`text-[11px] px-1.5 py-0.5 rounded font-bold ${
                  selectedDayIndex === idx ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-500'
                }`}>
                  {currency} {day.dayTotalEstimatedCost.toLocaleString()}
                </span>
              </button>
            ))}
          </div>

          {/* Current Day Schedule */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 mb-6">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Day {currentDay.dayNumber} of {itinerary.length}
                </span>
                <h3 className="text-lg font-extrabold text-slate-900">{currentDay.theme}</h3>
              </div>
              <div className="text-xs font-bold text-slate-700 bg-slate-100 px-3 py-1.5 rounded-lg">
                Estimated Day Expenses: {currency} {currentDay.dayTotalEstimatedCost.toLocaleString()}
              </div>
            </div>

            {/* Morning, Afternoon, Evening, Night Time Slots */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {currentDay.activities.map((act) => {
                const getSlotBadge = (slot: string) => {
                  switch (slot) {
                    case 'Morning':
                      return 'bg-amber-100 text-amber-800 border-amber-200';
                    case 'Afternoon':
                      return 'bg-blue-100 text-blue-800 border-blue-200';
                    case 'Evening':
                      return 'bg-purple-100 text-purple-800 border-purple-200';
                    default:
                      return 'bg-indigo-100 text-indigo-800 border-indigo-200';
                  }
                };

                return (
                  <div
                    key={act.id}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-indigo-300 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span
                          className={`text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${getSlotBadge(
                            act.timeSlot
                          )}`}
                        >
                          {act.timeSlot} ({act.time})
                        </span>
                        <span className="text-xs font-bold text-slate-900 bg-white border border-slate-200 px-2 py-0.5 rounded-md">
                          {act.costEstimate > 0 ? `${currency} ${act.costEstimate.toLocaleString()}` : 'Free'}
                        </span>
                      </div>

                      <h4 className="font-bold text-sm text-slate-900 mb-1">{act.title}</h4>
                      <p className="text-xs text-slate-600 leading-relaxed mb-3">{act.description}</p>
                    </div>

                    <div className="pt-3 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
                      <span className="flex items-center gap-1 font-medium text-slate-700">
                        <MapPin className="w-3.5 h-3.5 text-rose-500" /> {act.location}
                      </span>
                      {act.insiderTip && (
                        <span className="text-indigo-600 font-semibold cursor-help" title={act.insiderTip}>
                          💡 Tip: {act.insiderTip.slice(0, 30)}...
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Quick customization helper bar */}
            <div className="mt-6 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
              <span className="text-slate-600 font-medium">
                Want to change an activity or add something new?
              </span>
              <button
                type="button"
                onClick={() =>
                  onAskAssistant(
                    `Can you replace the afternoon activity on Day ${currentDay.dayNumber} with beach water sports?`
                  )
                }
                className="px-3.5 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                Ask Assistant to Change Day {currentDay.dayNumber}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FLIGHTS */}
      {activeTab === 'flights' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
              <div>
                <h3 className="font-bold text-base text-slate-900">
                  Recommended Flight Tickets
                </h3>
                <p className="text-xs text-slate-500">
                  Selected for the best departure time so you have maximum daylight on your trip.
                </p>
              </div>
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-sky-50 text-sky-700 border border-sky-200">
                Round-trip for {request.travelers} People
              </span>
            </div>

            {/* Currently Selected Flight */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-sky-50 to-indigo-50/50 border-2 border-sky-500 shadow-sm relative mb-6">
              <span className="absolute -top-3 left-6 px-3 py-0.5 rounded-full bg-sky-600 text-white text-[11px] font-bold uppercase tracking-wider shadow-xs">
                ★ Selected Flight ({flights.selectedFlight.airline})
              </span>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mt-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-lg text-slate-900">
                      {flights.selectedFlight.airline}
                    </span>
                    <span className="text-xs font-mono font-bold bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-700">
                      {flights.selectedFlight.flightNumber}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    {flights.selectedFlight.stopDetails || 'Non-stop Direct Flight'} • Total Flight Time: {flights.selectedFlight.duration}
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    🧳 Luggage: {flights.selectedFlight.baggage}
                  </p>
                </div>

                {/* Timings */}
                <div className="flex items-center gap-4 text-center">
                  <div>
                    <div className="text-lg font-extrabold text-slate-900">
                      {flights.selectedFlight.departureTime}
                    </div>
                    <div className="text-xs text-slate-500">{flights.selectedFlight.from}</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] text-slate-400 font-semibold">
                      {flights.selectedFlight.duration}
                    </span>
                    <div className="w-16 h-0.5 bg-slate-300 relative my-1">
                      <div className="w-2 h-2 rounded-full bg-sky-500 absolute -top-0.75 right-0" />
                    </div>
                    <span className="text-[10px] text-emerald-600 font-bold">Direct Flight</span>
                  </div>
                  <div>
                    <div className="text-lg font-extrabold text-slate-900">
                      {flights.selectedFlight.arrivalTime}
                    </div>
                    <div className="text-xs text-slate-500">{flights.selectedFlight.to}</div>
                  </div>
                </div>

                {/* Price & Booking Button */}
                <div className="flex flex-col items-end gap-2 shrink-0">
                  <div className="text-right">
                    <div className="text-xl font-extrabold text-slate-900">
                      {currency} {flights.selectedFlight.totalPrice.toLocaleString()}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      ({currency} {flights.selectedFlight.pricePerPerson.toLocaleString()} per person)
                    </div>
                  </div>
                  <a
                    href={flights.selectedFlight.bookingUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-xs transition-all"
                  >
                    Check Live Price & Book <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>

            {/* Other Flight Options */}
            <div>
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
                Other Flight Options You Can Pick:
              </h4>
              <div className="space-y-3">
                {flights.alternatives.map((alt) => (
                  <div
                    key={alt.id}
                    className="p-4 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{alt.airline}</span>
                        <span className="text-xs font-mono text-slate-500">{alt.flightNumber}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                          {alt.recommendedTag || 'Alternative Option'}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-1">
                        Departs {alt.departureTime} • Arrives {alt.arrivalTime} ({alt.duration}) • 🧳 {alt.baggage}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right">
                        <span className="font-extrabold text-sm text-slate-900">
                          {currency} {alt.totalPrice.toLocaleString()}
                        </span>
                        <span className="text-[10px] text-slate-500 block">Total for all</span>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleSelectFlight(alt)}
                        className="px-3 py-1.5 rounded-lg border border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs transition-all cursor-pointer"
                      >
                        Choose this Flight
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: HOTELS */}
      {activeTab === 'hotels' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
              <div>
                <h3 className="font-bold text-base text-slate-900">
                  Recommended Hotel & Stays
                </h3>
                <p className="text-xs text-slate-500">
                  {hotels.neighborhoodNotes || 'Chosen for cleanliness, positive ratings, and easy walking distance to attractions.'}
                </p>
              </div>
              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-purple-50 text-purple-700 border border-purple-200">
                {hotels.selectedHotel.totalNights} Nights • {request.travelers} Guests
              </span>
            </div>

            {/* Currently Selected Hotel */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-purple-50 to-indigo-50/50 border-2 border-purple-500 shadow-sm relative mb-6">
              <span className="absolute -top-3 left-6 px-3 py-0.5 rounded-full bg-purple-600 text-white text-[11px] font-bold uppercase tracking-wider shadow-xs">
                ★ Selected Hotel ({hotels.selectedHotel.name})
              </span>

              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mt-2">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-lg text-slate-900">
                      {hotels.selectedHotel.name}
                    </h4>
                    <span className="text-xs font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-md">
                      ★ {hotels.selectedHotel.rating}/5 ({hotels.selectedHotel.reviewCount} customer reviews)
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-rose-500" />
                    {hotels.selectedHotel.location} ({hotels.selectedHotel.distanceToCenter})
                  </p>

                  <p className="text-xs font-bold text-indigo-700">
                    Room Type: {hotels.selectedHotel.roomType}
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {hotels.selectedHotel.amenities.map((am, idx) => (
                      <span
                        key={idx}
                        className="text-xs font-medium px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-700"
                      >
                        ✓ {am}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2 shrink-0">
                  <div className="text-right">
                    <div className="text-xl font-extrabold text-slate-900">
                      {currency} {hotels.selectedHotel.totalPrice.toLocaleString()}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      {currency} {hotels.selectedHotel.pricePerNight.toLocaleString()} / night for {hotels.selectedHotel.totalNights} nights
                    </div>
                  </div>

                  <a
                    href={hotels.selectedHotel.bookingUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs transition-all"
                  >
                    View Hotel on Booking Site <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>

            {/* Alternative Hotels */}
            <div>
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
                Other Hotel Choices:
              </h4>
              <div className="space-y-3">
                {hotels.alternatives.map((alt) => (
                  <div
                    key={alt.id}
                    className="p-4 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{alt.name}</span>
                        <span className="text-xs font-bold text-amber-600">★ {alt.rating}/5</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                          {alt.recommendedTag || 'Alternative'}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-1">
                        {alt.location} • {alt.distanceToCenter} • Room: {alt.roomType}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right">
                        <span className="font-extrabold text-sm text-slate-900">
                          {currency} {alt.totalPrice.toLocaleString()}
                        </span>
                        <span className="text-[10px] text-slate-500 block">
                          ({currency} {alt.pricePerNight.toLocaleString()} / night)
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleSelectHotel(alt)}
                        className="px-3 py-1.5 rounded-lg border border-purple-200 bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold text-xs transition-all cursor-pointer"
                      >
                        Choose this Hotel
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: COST BREAKDOWN */}
      {activeTab === 'budget' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100 mb-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  Where Will Your Money Be Spent?
                </h3>
                <p className="text-xs text-slate-500">
                  Here is the clear cost breakdown for all {request.travelers} people across your entire {summary.durationDays}-day trip.
                </p>
              </div>

              <div className="flex items-center gap-4 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-500">Your Budget Cap</div>
                  <div className="text-base font-extrabold text-slate-900">
                    {currency} {budget.targetBudget.toLocaleString()}
                  </div>
                </div>
                <div className="w-px h-8 bg-slate-200" />
                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-500">Total Calculated Cost</div>
                  <div className="text-base font-extrabold text-indigo-700">
                    {currency} {budget.calculatedTotal.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>

            {/* Simple Cost Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              {budget.categories.map((cat, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white transition-all"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-xs text-slate-800">{cat.category}</span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-800">
                      {cat.percentage}% of total
                    </span>
                  </div>

                  <div className="text-xl font-extrabold text-slate-900 mb-1">
                    {currency} {cat.amount.toLocaleString()}
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">{cat.details}</p>
                </div>
              ))}
            </div>

            {/* Money-Saving Tips in simple language */}
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
              <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider mb-2">
                💡 Easy Tips to Save Money on this Trip:
              </h4>
              <ul className="space-y-1.5 text-xs text-emerald-950 font-medium">
                {budget.tipsForSaving.map((tip, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: HOW TO BOOK (SAFEGUARD CHECKLIST) */}
      {activeTab === 'booking' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm">
            <div className="flex items-start gap-4 pb-6 border-b border-slate-100 mb-6">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  Easy Booking Guide & Approval Checklist
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  <strong>Important:</strong> We do not take money from your bank account or card. You will book directly on trusted travel websites when you are ready. Review your plan below:
                </p>
              </div>
            </div>

            {/* Checklist */}
            <div className="space-y-4 mb-8">
              {/* Flight Item */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
                    <Plane className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">
                      Step 1: Flights ({flights.selectedFlight.airline})
                    </h4>
                    <span className="text-xs text-slate-500">
                      {currency} {flights.selectedFlight.totalPrice.toLocaleString()} total for {request.travelers} travelers
                    </span>
                  </div>
                </div>
                <a
                  href={flights.selectedFlight.bookingUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-all flex items-center gap-1"
                >
                  Book Flight Online <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Hotel Item */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
                    <Building className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">
                      Step 2: Hotel Stay ({hotels.selectedHotel.name})
                    </h4>
                    <span className="text-xs text-slate-500">
                      {hotels.selectedHotel.totalNights} Nights • {currency} {hotels.selectedHotel.totalPrice.toLocaleString()} total
                    </span>
                  </div>
                </div>
                <a
                  href={hotels.selectedHotel.bookingUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-all flex items-center gap-1"
                >
                  Book Hotel Online <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Transport Item */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                    <Car className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">
                      Step 3: Scooter or Taxi on Arrival
                    </h4>
                    <span className="text-xs text-slate-500">
                      Available directly at hotel counter (~{currency} 400 - 500 per day for an Activa scooter)
                    </span>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                  Pay at Location
                </span>
              </div>
            </div>

            {/* Approval Box */}
            <div className="p-5 rounded-xl bg-indigo-50 border border-indigo-200">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={approvedChecked}
                  onChange={(e) => {
                    setApprovedChecked(e.target.checked);
                    if (e.target.checked) handleApprovePlan();
                  }}
                  className="mt-1 w-4 h-4 accent-indigo-600 rounded cursor-pointer"
                />
                <div>
                  <span className="font-bold text-sm text-slate-900 block">
                    I have checked this trip plan and budget. Everything looks good to me!
                  </span>
                  <span className="text-xs text-slate-600">
                    Confirm your approval so you can save and print your final travel plan.
                  </span>
                </div>
              </label>

              <div className="mt-4 pt-4 border-t border-indigo-200 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleApprovePlan}
                  disabled={approvedChecked}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition-all disabled:opacity-60 flex items-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  {approvedChecked ? 'Plan Approved ✓' : 'Click to Approve Plan'}
                </button>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={onSavePlan}
                    className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Bookmark className="w-4 h-4" /> {isPlanSaved ? 'Saved!' : 'Save Trip Plan'}
                  </button>
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="px-4 py-2.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <Printer className="w-4 h-4" /> Print Plan
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
