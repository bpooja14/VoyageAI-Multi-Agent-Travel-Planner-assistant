import React from 'react';
import { TripPlan } from '../types';
import {
  BookmarkCheck,
  Calendar,
  Users,
  Wallet,
  ArrowRight,
  Trash2,
  Printer,
  MapPin,
  Sparkles,
  Plane,
  Building,
} from 'lucide-react';

interface SavedTripsHistoryProps {
  savedTrips: TripPlan[];
  onSelectTrip: (plan: TripPlan) => void;
  onDeleteTrip: (id: string) => void;
  onLoadBenchmarkGoa: () => void;
}

export const SavedTripsHistory: React.FC<SavedTripsHistoryProps> = ({
  savedTrips,
  onSelectTrip,
  onDeleteTrip,
  onLoadBenchmarkGoa,
}) => {
  return (
    <div className="max-w-5xl mx-auto py-8 px-4 sm:px-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-xs font-bold text-indigo-700 mb-2">
            <BookmarkCheck className="w-3.5 h-3.5 text-indigo-600" /> Saved Travel Plans
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            My Saved Trips ({savedTrips.length})
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            All the trip itineraries you have saved. Open, review, or print them anytime.
          </p>
        </div>

        <button
          type="button"
          onClick={onLoadBenchmarkGoa}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow-xs transition-all shrink-0 cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          Load 3-Day Goa Sample Trip (₹25,000)
        </button>
      </div>

      {savedTrips.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
            <BookmarkCheck className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-900">No Saved Trips Yet</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
            When you view any trip plan in 'Your Trip Plan', simply click the yellow <strong>"Save This Trip Plan"</strong> button, and it will be stored right here!
          </p>
          <button
            type="button"
            onClick={onLoadBenchmarkGoa}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-bold text-xs hover:bg-indigo-700 transition-all inline-flex items-center gap-1.5 cursor-pointer"
          >
            Load 3-Day Goa Plan to Start
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {savedTrips.map((plan) => {
            const curr = plan.request.currency || '₹';
            return (
              <div
                key={plan.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-200">
                      {plan.summary.durationDays} Days • {plan.request.travelers} {plan.request.travelers === 1 ? 'Person' : 'People'}
                    </span>
                    <span className="text-xs text-slate-400">
                      Saved on {new Date(plan.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  <h3 className="font-extrabold text-base text-slate-900 mb-1">
                    {plan.summary.title}
                  </h3>

                  <p className="text-xs text-slate-500 flex items-center gap-1 mb-3">
                    <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                    {plan.request.destination} (Departing from {plan.request.originCity || 'Home'})
                  </p>

                  <div className="grid grid-cols-3 gap-2 p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs mb-4">
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-bold block">Total Cost</span>
                      <span className="font-extrabold text-slate-900">
                        {curr} {plan.budget.calculatedTotal.toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-bold block">Your Budget</span>
                      <span className="font-bold text-slate-700">
                        {curr} {plan.request.budget.toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-bold block">Budget Result</span>
                      <span className="font-bold text-emerald-600">
                        Within Budget ✓
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1 text-xs text-slate-600 mb-4">
                    <div className="flex items-center gap-1.5">
                      <Plane className="w-3.5 h-3.5 text-sky-600" />
                      <span>{plan.flights.selectedFlight.airline} ({plan.flights.selectedFlight.flightNumber})</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Building className="w-3.5 h-3.5 text-purple-600" />
                      <span>{plan.hotels.selectedHotel.name}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onDeleteTrip(plan.id)}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete this saved trip"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                      title="Print this trip plan"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectTrip(plan)}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    Open Trip Plan <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
