export type AgentType = 'coordinator' | 'flight' | 'hotel' | 'itinerary' | 'budget';

export interface TripRequest {
  id?: string;
  destination: string;
  originCity: string;
  startDate: string;
  endDate: string;
  travelers: number;
  budget: number;
  currency: string;
  interests: string[];
  travelStyle: 'Budget' | 'Balanced' | 'Luxury' | 'Adventure' | 'Relaxed';
  accommodationType: string;
  transportPreference?: 'Flight' | 'Train' | 'Self-Drive' | 'Best Option';
}

export interface FlightOption {
  id: string;
  airline: string;
  flightNumber: string;
  from: string;
  to: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  stops: number;
  stopDetails?: string;
  pricePerPerson: number;
  totalPrice: number;
  currency: string;
  baggage: string;
  bookingUrl: string;
  recommendedTag?: string;
  selected?: boolean;
}

export interface HotelOption {
  id: string;
  name: string;
  location: string;
  distanceToCenter: string;
  stars: number;
  rating: number;
  reviewCount: number;
  pricePerNight: number;
  totalNights: number;
  totalPrice: number;
  currency: string;
  amenities: string[];
  roomType: string;
  imageUrl?: string;
  bookingUrl: string;
  recommendedTag?: string;
  selected?: boolean;
}

export interface ActivityItem {
  id: string;
  timeSlot: 'Morning' | 'Afternoon' | 'Evening' | 'Night';
  time: string;
  title: string;
  description: string;
  location: string;
  duration: string;
  costEstimate: number;
  currency: string;
  category: 'Sightseeing' | 'Food & Drink' | 'Adventure' | 'Culture' | 'Relaxation' | 'Transit';
  bookingUrl?: string;
  insiderTip?: string;
}

export interface DayPlan {
  dayNumber: number;
  date: string;
  theme: string;
  activities: ActivityItem[];
  dayTotalEstimatedCost: number;
}

export interface CostCategory {
  category: string;
  amount: number;
  percentage: number;
  details: string;
  iconName: string;
}

export interface BudgetBreakdown {
  currency: string;
  targetBudget: number;
  calculatedTotal: number;
  balance: number;
  isWithinBudget: boolean;
  savingsOrOverrun: number;
  categories: CostCategory[];
  optimizationHistory: string[];
  tipsForSaving: string[];
}

export interface AgentExecutionLog {
  agent: AgentType;
  title: string;
  status: 'pending' | 'running' | 'completed' | 'optimized' | 'delegated';
  summary: string;
  details: string;
  timestamp: string;
  iteration?: number;
}

export interface TripPlan {
  id: string;
  createdAt: string;
  request: TripRequest;
  summary: {
    title: string;
    description: string;
    durationDays: number;
    destinationHighlights: string[];
    bestTimeToVisit: string;
    weatherForecast: string;
    overallRecommendationScore: number;
  };
  flights: {
    selectedFlight: FlightOption;
    alternatives: FlightOption[];
    notes: string;
  };
  hotels: {
    selectedHotel: HotelOption;
    alternatives: HotelOption[];
    neighborhoodNotes: string;
  };
  itinerary: DayPlan[];
  budget: BudgetBreakdown;
  agentLogs: AgentExecutionLog[];
  validationStatus: {
    passed: boolean;
    iterationsRun: number;
    budgetChecked: boolean;
    datesChecked: boolean;
    travelTimesChecked: boolean;
    optimizationNotes: string;
  };
  approvedByCustomer: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  agent?: AgentType;
  agentName?: string;
  agentAvatar?: string;
  text: string;
  timestamp: string;
  suggestedActions?: string[];
  planModification?: {
    type: 'budget' | 'itinerary' | 'hotel' | 'flight';
    summary: string;
    updatedData?: any;
  };
}
