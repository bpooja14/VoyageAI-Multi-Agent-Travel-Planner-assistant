import { AgentType, ChatMessage, TripPlan } from '../src/types';
import { getGeminiClient, withTimeout } from './geminiClient';

export interface ChatResponsePayload {
  message: ChatMessage;
  updatedPlan?: Partial<TripPlan>;
  agentRouted: AgentType;
  agentName: string;
  agentAvatar: string;
}

export async function handleChatQuery(
  userQuery: string,
  currentPlan: TripPlan | null,
  chatHistory: ChatMessage[],
  preferredLanguage: string = 'English'
): Promise<ChatResponsePayload> {
  const queryLower = userQuery.toLowerCase();

  let targetAgent: AgentType = 'coordinator';
  let agentName = 'Travel Assistant';
  let agentAvatar = '🤖';

  if (
    queryLower.includes('flight') ||
    queryLower.includes('airline') ||
    queryLower.includes('indigo') ||
    queryLower.includes('baggage') ||
    queryLower.includes('luggage') ||
    queryLower.includes('terminal') ||
    queryLower.includes('boarding') ||
    queryLower.includes('airfare') ||
    queryLower.includes('ticket')
  ) {
    targetAgent = 'flight';
    agentName = 'Flight Helper';
    agentAvatar = '✈️';
  } else if (
    queryLower.includes('hotel') ||
    queryLower.includes('resort') ||
    queryLower.includes('room') ||
    queryLower.includes('stay') ||
    queryLower.includes('check-in') ||
    queryLower.includes('checkout') ||
    queryLower.includes('pool') ||
    queryLower.includes('beach view') ||
    queryLower.includes('hostel')
  ) {
    targetAgent = 'hotel';
    agentName = 'Hotel Helper';
    agentAvatar = '🏨';
  } else if (
    queryLower.includes('budget') ||
    queryLower.includes('cost') ||
    queryLower.includes('rupee') ||
    queryLower.includes('cheap') ||
    queryLower.includes('expensive') ||
    queryLower.includes('money') ||
    queryLower.includes('price') ||
    queryLower.includes('over budget') ||
    queryLower.includes('save') ||
    queryLower.includes('₹')
  ) {
    targetAgent = 'budget';
    agentName = 'Money & Budget Helper';
    agentAvatar = '💰';
  } else if (
    queryLower.includes('itinerary') ||
    queryLower.includes('activity') ||
    queryLower.includes('beach') ||
    queryLower.includes('museum') ||
    queryLower.includes('replace') ||
    queryLower.includes('sightseeing') ||
    queryLower.includes('scooter') ||
    queryLower.includes('food') ||
    queryLower.includes('dinner') ||
    queryLower.includes('day 1') ||
    queryLower.includes('day 2') ||
    queryLower.includes('day 3') ||
    queryLower.includes('change')
  ) {
    targetAgent = 'itinerary';
    agentName = 'Schedule Helper';
    agentAvatar = '📅';
  }

  const tripContext = currentPlan
    ? `Current Trip Details:
- Destination: ${currentPlan.request.destination}
- Duration: ${currentPlan.summary.durationDays} days (${currentPlan.request.startDate} to ${currentPlan.request.endDate})
- Travelers: ${currentPlan.request.travelers} people
- User Budget: ${currentPlan.request.currency} ${currentPlan.request.budget}
- Total Calculated Cost: ${currentPlan.request.currency} ${currentPlan.budget.calculatedTotal}
- Chosen Flight: ${currentPlan.flights.selectedFlight.airline} (${currentPlan.request.currency} ${currentPlan.flights.selectedFlight.totalPrice})
- Chosen Hotel: ${currentPlan.hotels.selectedHotel.name} in ${currentPlan.hotels.selectedHotel.location} (${currentPlan.request.currency} ${currentPlan.hotels.selectedHotel.totalPrice})`
    : 'No trip planned yet.';

  const ai = getGeminiClient();
  if (ai) {
    try {
      const prompt = `You are the ${agentName} (${agentAvatar}) in the VoyageAI Travel Planning Assistant.
The customer is asking: "${userQuery}"

${tripContext}

Rules:
1. Write ONLY in simple, friendly, easy-to-understand English.
2. DO NOT use technical jargon like "NLP", "orchestration", "dynamic envelopes". Speak like a friendly, helpful human travel expert.
3. If they ask about budget (e.g. "Is ₹25,000 enough for Goa?"), break down the expenses simply: flights, hotel, food, scooter rental, and emergency buffer.
4. If they ask to modify or make it cheaper, explain the simple steps (e.g. switch to scooter instead of cabs, choose boutique hotel).
5. Reassure the customer that no money is deducted automatically; they book directly when they are ready.
6. Keep the answer clear and concise (under 160 words).

Response:`;

      const response = await withTimeout(
        ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            temperature: 0.3,
          },
        }),
        3000
      );

      if (response.text) {
        return {
          message: {
            id: `msg-${Date.now()}`,
            sender: 'assistant',
            agent: targetAgent,
            agentName,
            agentAvatar,
            text: response.text.trim(),
            timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
            suggestedActions: getSimpleSuggestedActions(targetAgent),
          },
          agentRouted: targetAgent,
          agentName,
          agentAvatar,
        };
      }
    } catch (err) {
      console.warn('Gemini chat call failed, using clear English rule engine:', err);
    }
  }

  // Clear English Fallback
  const text = getSimpleEnglishAnswer(userQuery, targetAgent, agentName, agentAvatar, currentPlan);

  return {
    message: {
      id: `msg-${Date.now()}`,
      sender: 'assistant',
      agent: targetAgent,
      agentName,
      agentAvatar,
      text,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      suggestedActions: getSimpleSuggestedActions(targetAgent),
    },
    agentRouted: targetAgent,
    agentName,
    agentAvatar,
  };
}

function getSimpleSuggestedActions(agent: AgentType): string[] {
  switch (agent) {
    case 'flight':
      return ['Check baggage allowance', 'Compare other airlines', 'Pick earlier flight'];
    case 'hotel':
      return ['Which hotel is near the beach?', 'See hotel swimming pool & photos', 'Compare cheaper hotel'];
    case 'budget':
      return ['How to save ₹3,000 on this trip', 'Show full cost breakdown', 'Rent a scooter to save money'];
    case 'itinerary':
      return ['Replace museum with beach water sports', 'Best local seafood shacks', 'Day 2 schedule'];
    default:
      return ['Is ₹25,000 enough for Goa?', 'Save this trip plan', 'Talk to human support'];
  }
}

function getSimpleEnglishAnswer(
  query: string,
  agent: AgentType,
  name: string,
  avatar: string,
  plan: TripPlan | null
): string {
  const q = query.toLowerCase();
  const dest = plan?.request.destination || 'Goa';
  const curr = plan?.request.currency || '₹';

  if (q.includes('25000') || (q.includes('enough') && q.includes('goa'))) {
    return `Yes! ₹25,000 is a very good and comfortable budget for a 3-day Goa trip for 2 people.

Here is the simple breakdown of where your money will go:
• Return flight tickets (Mumbai ⇄ Goa for 2 people): ~₹7,600
• 3-star resort with swimming pool & free breakfast (2 nights): ~₹5,000
• Activa scooter rental (3 days + petrol): ~₹1,800
• Good food, fresh seafood & drinks: ~₹4,500
• Sightseeing, forts & beach activities: ~₹2,700
• Extra emergency safety money: ~₹1,200

Total comes to around ₹22,800, leaving you with an extra ₹2,200 saved in your pocket!`;
  }

  if (q.includes('beach') && (q.includes('hotel') || q.includes('near') || q.includes('close'))) {
    const hotel = plan?.hotels.selectedHotel;
    return `Our chosen stay, "${hotel?.name || 'La Oasis Beach Resort'}", is just a 5-minute walk (about 450 meters) from the beach. You can easily walk to the sand and beach shacks without needing to pay for expensive taxis!`;
  }

  if (q.includes('cheaper') || q.includes('over budget') || q.includes('save') || q.includes('reduce')) {
    return `Here are 3 easy ways we can make your trip cheaper:
1. Rent an Activa scooter (₹400/day) instead of booking private cabs (saves about ₹2,000 per day).
2. Choose our Boutique Saver hotel in Anjuna instead of the beachfront resort (saves ₹1,400).
3. Visit scenic natural sunset viewpoints (like Chapora Fort) instead of commercial party boats.

These changes will save you around ₹3,500 easily!`;
  }

  if (q.includes('replace') || q.includes('museum') || q.includes('water sports')) {
    return `Done! I have replaced the indoor museum on Day 2 with an exciting Water Sports & Beach session at Calangute Beach (Parasailing, Jet Ski, and Banana Ride). The timing is set for late afternoon when the sun is pleasant!`;
  }

  if (q.includes('scooter') || q.includes('bike') || q.includes('rent')) {
    return `Renting an Activa scooter is the best and cheapest way to get around Goa. It costs only ₹400 to ₹500 per day. You only need your driving license. You can rent it directly at the hotel front desk when you arrive!`;
  }

  if (q.includes('booking') || q.includes('pay') || q.includes('card') || q.includes('charge') || q.includes('automatically')) {
    return `We NEVER charge your card or take money automatically. VoyageAI gives you verified links to trusted websites like MakeMyTrip and Booking.com. You only book and pay when you are completely satisfied with your plan.`;
  }

  return `I am here to help with your ${dest} trip! You can ask me to change any hotel, check flight luggage, or help you save money. What would you like to know?`;
}
