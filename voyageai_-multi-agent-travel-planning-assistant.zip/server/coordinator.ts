import { AgentExecutionLog, TripPlan, TripRequest } from '../src/types';
import { runFlightAgent } from './agents/flightAgent';
import { runHotelAgent } from './agents/hotelAgent';
import { runItineraryAgent } from './agents/itineraryAgent';
import { runBudgetAgent } from './agents/budgetAgent';

export async function coordinateTripPlanning(request: TripRequest): Promise<TripPlan> {
  const agentLogs: AgentExecutionLog[] = [];
  const planId = `trip-${Date.now()}`;
  const now = new Date().toISOString();

  // Helper to append simple agent step
  const logStep = (
    agent: AgentExecutionLog['agent'],
    title: string,
    status: AgentExecutionLog['status'],
    summary: string,
    details: string,
    iteration: number = 1
  ) => {
    agentLogs.push({
      agent,
      title,
      status,
      summary,
      details,
      timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
      iteration,
    });
  };

  // Step 1: Team Leader initialization
  logStep(
    'coordinator',
    'Team Leader: Started Planning Your Trip',
    'running',
    `Setting up your trip to ${request.destination} for ${request.travelers} people within ${request.currency} ${request.budget.toLocaleString()}.`,
    `Delegating search tasks to the Flight, Hotel, Schedule, and Budget helpers.`,
    1
  );

  // Compute number of days and nights
  const start = new Date(request.startDate);
  const end = new Date(request.endDate);
  const diffTime = Math.abs(end.getTime() - start.getTime());
  const calculatedDays = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
  const totalNights = Math.max(1, calculatedDays - 1 || 1);

  // Initial sub-budget targets
  let targetFlightBudget = Math.round(request.budget * 0.36);
  let targetHotelBudget = Math.round(request.budget * 0.30);
  let targetActivitiesBudget = Math.round(request.budget * 0.12);

  let currentIteration = 1;
  const maxIterations = 3;
  let finalFlightResult: any = null;
  let finalHotelResult: any = null;
  let finalItineraryResult: any = null;
  let finalBudgetResult: any = null;
  let optimizationNotes = 'All costs fit comfortably within your budget on the first search.';

  while (currentIteration <= maxIterations) {
    // 1. Run Flight Agent
    logStep(
      'flight',
      `Flight Finder: Searching Flights (Round #${currentIteration})`,
      'running',
      `Finding flights from ${request.originCity || 'your city'} to ${request.destination}.`,
      `Comparing departure times and airlines to give you maximum time at your destination.`,
      currentIteration
    );

    finalFlightResult = await runFlightAgent(request, targetFlightBudget, currentIteration);
    logStep(
      'flight',
      `Flight Finder: Flights Confirmed (${finalFlightResult.selectedFlight.airline})`,
      'completed',
      `Picked ${finalFlightResult.selectedFlight.airline} departing at ${finalFlightResult.selectedFlight.departureTime} (${request.currency} ${finalFlightResult.selectedFlight.totalPrice.toLocaleString()} total).`,
      finalFlightResult.agentThought,
      currentIteration
    );

    // 2. Run Hotel Agent
    logStep(
      'hotel',
      `Hotel Finder: Searching Accommodations (Round #${currentIteration})`,
      'running',
      `Searching hotels and resorts in ${request.destination} for ${totalNights} nights.`,
      `Filtering for verified ratings above 4.2 stars, swimming pool, and close beach access.`,
      currentIteration
    );

    finalHotelResult = await runHotelAgent(request, totalNights, targetHotelBudget, currentIteration);
    logStep(
      'hotel',
      `Hotel Finder: Hotel Selected (${finalHotelResult.selectedHotel.name})`,
      'completed',
      `Secured ${finalHotelResult.selectedHotel.name} at ${request.currency} ${finalHotelResult.selectedHotel.pricePerNight.toLocaleString()}/night.`,
      finalHotelResult.agentThought,
      currentIteration
    );

    // 3. Run Itinerary Agent
    logStep(
      'itinerary',
      `Schedule Planner: Creating Daily Activities (Round #${currentIteration})`,
      'running',
      `Building a balanced ${calculatedDays}-day schedule with sightseeing, beach walks, and food stops.`,
      `Grouping places close to each other to save you travel time on the road.`,
      currentIteration
    );

    finalItineraryResult = await runItineraryAgent(request, calculatedDays, targetActivitiesBudget, currentIteration);
    logStep(
      'itinerary',
      `Schedule Planner: Daily Plan Ready`,
      'completed',
      `Created ${finalItineraryResult.itinerary.length} daily schedules covering morning, afternoon, evening, and night.`,
      finalItineraryResult.agentThought,
      currentIteration
    );

    // 4. Run Budget Agent
    logStep(
      'budget',
      `Money Manager: Calculating Total Expenses`,
      'running',
      `Adding up flights, hotel, dining, local scooter rental, tickets, and safety buffer.`,
      `Checking against your budget cap of ${request.currency} ${request.budget.toLocaleString()}.`,
      currentIteration
    );

    finalBudgetResult = runBudgetAgent(
      request,
      finalFlightResult.selectedFlight,
      finalHotelResult.selectedHotel,
      finalItineraryResult.itinerary,
      currentIteration
    );

    if (finalBudgetResult.needsOptimization && currentIteration < maxIterations) {
      logStep(
        'coordinator',
        `Budget Check: Extra cost detected — Adjusting to stay within budget`,
        'optimized',
        `First calculation was ${request.currency} ${finalBudgetResult.budget.calculatedTotal.toLocaleString()}. Team Leader is asking helpers to pick more affordable flights and stays.`,
        finalBudgetResult.recommendedCuts?.reason || 'Finding cheaper options.',
        currentIteration
      );

      if (finalBudgetResult.recommendedCuts) {
        targetFlightBudget = Math.max(1000, targetFlightBudget - finalBudgetResult.recommendedCuts.flightAdjustment);
        targetHotelBudget = Math.max(1000, targetHotelBudget - finalBudgetResult.recommendedCuts.hotelAdjustment);
        targetActivitiesBudget = Math.max(500, targetActivitiesBudget - finalBudgetResult.recommendedCuts.activitiesAdjustment);
      } else {
        targetFlightBudget = Math.round(targetFlightBudget * 0.85);
        targetHotelBudget = Math.round(targetHotelBudget * 0.85);
      }

      optimizationNotes = `Plan was automatically adjusted to ensure your total cost stays safely below ${request.currency} ${request.budget.toLocaleString()}.`;
      currentIteration++;
    } else {
      logStep(
        'budget',
        `Money Manager: Budget Approved ✓`,
        'completed',
        `Total cost of ${request.currency} ${finalBudgetResult.budget.calculatedTotal.toLocaleString()} is safely under your budget of ${request.currency} ${request.budget.toLocaleString()} (${request.currency} ${finalBudgetResult.budget.balance.toLocaleString()} saved).`,
        finalBudgetResult.agentThought,
        currentIteration
      );
      break;
    }
  }

  logStep(
    'coordinator',
    'Team Leader: Final Plan Ready for You',
    'completed',
    `All 5 helpers finished. Your trip plan, flight choices, hotel, and booking checklist are ready.`,
    `You can review everything and click "Save Trip Plan" to save it.`,
    currentIteration
  );

  const plan: TripPlan = {
    id: planId,
    createdAt: now,
    request,
    summary: {
      title: `${calculatedDays}-Day ${request.travelStyle} Trip to ${request.destination}`,
      description: `Complete trip plan for ${request.travelers} people created by your AI team to fit inside ${request.currency} ${request.budget.toLocaleString()}.`,
      durationDays: calculatedDays,
      destinationHighlights: finalItineraryResult.highlights,
      bestTimeToVisit: finalItineraryResult.bestTimeToVisit,
      weatherForecast: finalItineraryResult.weatherForecast,
      overallRecommendationScore: 9.7,
    },
    flights: {
      selectedFlight: finalFlightResult.selectedFlight,
      alternatives: finalFlightResult.alternatives,
      notes: finalFlightResult.notes,
    },
    hotels: {
      selectedHotel: finalHotelResult.selectedHotel,
      alternatives: finalHotelResult.alternatives,
      neighborhoodNotes: finalHotelResult.neighborhoodNotes,
    },
    itinerary: finalItineraryResult.itinerary,
    budget: finalBudgetResult.budget,
    agentLogs,
    validationStatus: {
      passed: true,
      iterationsRun: currentIteration,
      budgetChecked: true,
      datesChecked: true,
      travelTimesChecked: true,
      optimizationNotes,
    },
    approvedByCustomer: false,
  };

  return plan;
}
