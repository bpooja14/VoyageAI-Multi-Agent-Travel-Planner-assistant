import { BudgetBreakdown, CostCategory, FlightOption, HotelOption, DayPlan, TripRequest } from '../../src/types';

export interface BudgetAgentResult {
  budget: BudgetBreakdown;
  needsOptimization: boolean;
  agentThought: string;
  recommendedCuts?: {
    flightAdjustment: number;
    hotelAdjustment: number;
    activitiesAdjustment: number;
    reason: string;
  };
}

export function runBudgetAgent(
  request: TripRequest,
  selectedFlight: FlightOption,
  selectedHotel: HotelOption,
  itinerary: DayPlan[],
  iteration: number = 1
): BudgetAgentResult {
  const { budget: targetBudget, currency, travelers } = request;
  const daysCount = itinerary.length;

  const flightsCost = selectedFlight.totalPrice;
  const hotelCost = selectedHotel.totalPrice;

  // Itinerary activities cost
  const activitiesCost = itinerary.reduce((sum, day) => {
    return sum + day.activities.reduce((dSum, act) => {
      // Exclude Food & Drink from raw activity category since we itemize food separately
      if (act.category === 'Food & Drink') return dSum;
      return dSum + act.costEstimate;
    }, 0);
  }, 0);

  // Estimate food & dining (3 meals a day per traveler)
  // For budget travel in India, approx ₹600 - ₹900 per person/day
  const isBudgetConstraint = iteration > 1;
  const dailyFoodPerPerson = isBudgetConstraint ? 550 : 750;
  const foodCost = Math.round(dailyFoodPerPerson * travelers * daysCount);

  // Local transport (scooter rental or rideshare)
  // E.g., 1 scooter for 2 people = ₹450/day + ₹200 fuel = ₹650/day
  const dailyLocalTransport = Math.round((travelers > 2 ? 1200 : 650) * daysCount);

  // Government taxes, airport cess & 5% safety buffer
  const rawSubtotal = flightsCost + hotelCost + foodCost + dailyLocalTransport + activitiesCost;
  const safetyBuffer = Math.round(rawSubtotal * 0.05);

  const calculatedTotal = rawSubtotal + safetyBuffer;
  const balance = targetBudget - calculatedTotal;
  const isWithinBudget = balance >= 0;
  const savingsOrOverrun = Math.abs(balance);

  const categories: CostCategory[] = [
    {
      category: 'Flights & Air Travel',
      amount: flightsCost,
      percentage: Math.round((flightsCost / calculatedTotal) * 100),
      details: `${selectedFlight.airline} round-trip for ${travelers} travelers (${selectedFlight.from} ⇄ ${selectedFlight.to})`,
      iconName: 'Plane',
    },
    {
      category: 'Hotel & Stays',
      amount: hotelCost,
      percentage: Math.round((hotelCost / calculatedTotal) * 100),
      details: `${selectedHotel.name} (${selectedHotel.totalNights} nights, ${selectedHotel.roomType})`,
      iconName: 'Hotel',
    },
    {
      category: 'Food & Culinary Experiences',
      amount: foodCost,
      percentage: Math.round((foodCost / calculatedTotal) * 100),
      details: `Breakfast (included at stay/cafe), beach lunches & coastal dinners for ${daysCount} days`,
      iconName: 'Utensils',
    },
    {
      category: 'Local Transport & Rentals',
      amount: dailyLocalTransport,
      percentage: Math.round((dailyLocalTransport / calculatedTotal) * 100),
      details: travelers <= 2 ? `Self-drive scooter rental + fuel for ${daysCount} days` : `Shared airport transfers + taxi rides`,
      iconName: 'Car',
    },
    {
      category: 'Sightseeing & Entry Fees',
      amount: activitiesCost,
      percentage: Math.round((activitiesCost / calculatedTotal) * 100),
      details: `Fort entry, museum tickets, and sunset activities across ${daysCount} days`,
      iconName: 'Ticket',
    },
    {
      category: 'Taxes & Emergency Buffer',
      amount: safetyBuffer,
      percentage: Math.round((safetyBuffer / calculatedTotal) * 100),
      details: `5% contingency fund reserved for unexpected travel needs or tips`,
      iconName: 'ShieldCheck',
    },
  ];

  const tipsForSaving: string[] = [
    'Rent an Activa scooter (₹400/day) instead of relying on tourist taxis (₹2,500/day) in Goa.',
    'Enjoy beach shacks and local family-run eateries for fresh seafood at half resort prices.',
    'Book domestic flights 3+ weeks ahead or select mid-week departures to save up to 25%.',
    'Take advantage of complimentary hotel breakfast before setting out for morning sightseeing.',
  ];

  const optimizationHistory: string[] = [];
  if (iteration === 1) {
    optimizationHistory.push(`Initial plan compiled: Total calculated ${currency} ${calculatedTotal.toLocaleString()} against budget ${currency} ${targetBudget.toLocaleString()}.`);
  } else {
    optimizationHistory.push(
      `Optimization iteration #${iteration}: Re-balanced flight fare classes and substituted premium activities with scenic free viewpoints.`
    );
  }

  let recommendedCuts;
  if (!isWithinBudget) {
    const deficit = calculatedTotal - targetBudget;
    recommendedCuts = {
      flightAdjustment: Math.round(deficit * 0.45),
      hotelAdjustment: Math.round(deficit * 0.40),
      activitiesAdjustment: Math.round(deficit * 0.15),
      reason: `Plan exceeded budget by ${currency} ${deficit.toLocaleString()}. Delegating downward adjustments to Flight, Hotel and Itinerary agents.`,
    };
    optimizationHistory.push(recommendedCuts.reason);
  } else {
    optimizationHistory.push(`Budget validated successfully! Surplus safety cushion: ${currency} ${balance.toLocaleString()}.`);
  }

  const agentThought = isWithinBudget
    ? `Budget Agent verified all 6 expenditure pillars. Total comes to ${currency} ${calculatedTotal.toLocaleString()}, comfortably under user cap of ${currency} ${targetBudget.toLocaleString()} with ${currency} ${balance.toLocaleString()} left as cushion.`
    : `Budget Agent detected cost overrun of ${currency} ${savingsOrOverrun.toLocaleString()} (${Math.round((calculatedTotal / targetBudget) * 100)}% of cap). Initiating coordinator renegotiation loop.`;

  return {
    budget: {
      currency,
      targetBudget,
      calculatedTotal,
      balance,
      isWithinBudget,
      savingsOrOverrun,
      categories,
      optimizationHistory,
      tipsForSaving,
    },
    needsOptimization: !isWithinBudget,
    agentThought,
    recommendedCuts,
  };
}
