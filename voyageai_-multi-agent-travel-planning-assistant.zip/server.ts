import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { coordinateTripPlanning } from './server/coordinator';
import { handleChatQuery } from './server/chatAssistant';
import { TripRequest } from './src/types';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // API Route: Multi-Agent Trip Planner Workflow
  app.post('/api/plan-trip', async (req: Request, res: Response) => {
    try {
      const tripRequest: TripRequest = req.body;
      if (!tripRequest.destination || !tripRequest.budget) {
        return res.status(400).json({ error: 'Destination and budget are required.' });
      }
      const plan = await coordinateTripPlanning(tripRequest);
      res.json(plan);
    } catch (err: any) {
      console.error('Error generating trip plan:', err);
      res.status(500).json({ error: err.message || 'Failed to coordinate trip plan' });
    }
  });

  // API Route: Multi-Agent AI Travel Chat Assistant
  app.post('/api/chat', async (req: Request, res: Response) => {
    try {
      const { query, currentPlan, history, language } = req.body;
      if (!query) {
        return res.status(400).json({ error: 'Query is required.' });
      }
      const response = await handleChatQuery(query, currentPlan, history || [], language || 'English');
      res.json(response);
    } catch (err: any) {
      console.error('Error handling chat query:', err);
      res.status(500).json({ error: err.message || 'Chat assistant error' });
    }
  });

  // API Route: Support Ticket
  app.post('/api/support-ticket', (req: Request, res: Response) => {
    const { name, email, phone, question, tripId } = req.body;
    const ticketId = `TKT-${Math.floor(100000 + Math.random() * 900000)}`;
    res.json({
      success: true,
      ticketId,
      message: `Your query has been assigned to our human travel concierge (Ref #${ticketId}). We will reach out via WhatsApp/email within 15 minutes!`,
    });
  });

  // Vite Dev Server middleware or Static files in production
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`VoyageAI Multi-Agent Server running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
